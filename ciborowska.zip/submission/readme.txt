Running Spark-LDA:
1. Initial setup 
	1.1. Download apache + hadoop
	1.2. Setup pySpark (e.g. following https://datawookie.netlify.com/blog/2017/07/installing-spark-on-ubuntu/ )
	1.3. Paste provided conf/spark-defaults.conf to $SPARK_HOME/conf/
	1.4. Install packages listed at the top of the LDY.py script
	
2. Before running:
	2.1. Spark-LDA parameters are listed at the top of the script - use them according to your preferences
	2.2. Directory 'datasets' contains NIPS abstract dataset called 'abstract.csv'
	2.2. Perplexity and execution time are collected and saved after training and testing ends in 'results' directory
	2.2. After training and testing is done, script will try to produce visualization using pyldavis 
	     - for some reason server sometimes refuses to cooperate (not enough resources) and produces an error that I haven't ever encountered locally;
		   as this is not essential part of the project I left it as it is	¯\_(ツ)_/¯
		 - visualization results are saved in 'results/vis' directory   
		 
3. Running:
 ./$SPARK_HOME/bin/spark-submit LDA.py
		 
		